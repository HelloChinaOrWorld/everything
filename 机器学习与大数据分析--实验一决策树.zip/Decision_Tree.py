
import numpy as np
import pandas as pd
import Tree_visual
import matplotlib.pyplot as plt

#定义计算信息熵的函数
from pandas import Series
from math import log
def entropy(dataset,col):
    count_list = dataset[col].value_counts() # survived 的统计数据，例如,{0:10,1:20}仅作示例，但不是字典类型，而是数组
    total_nums = count_list.sum() #统计总数
    res = 0.0
    for num in count_list:
        p = num / total_nums
        res += -p*log(p)
    return res


def split(dataSet,col,key):
    index = (dataSet.loc[:,col] == key)
    return dataSet[index]

def split_value(dataSet,col,value):
    index_l = (dataSet.loc[:,col] <= value)
    index_r = (dataSet.loc[:,col] > value)
    return dataSet[index_l],dataSet[index_r]

def chooseBestFeature(dataSet,cols,target):
    if target in cols:
        cols = cols.drop(target)
    baseEntropy = entropy(dataSet,target)
    bestInfoGain = 0.0
    best_col = -1
    for col in cols:
        type_dict = dataSet[col].value_counts()
        keys = type_dict.keys()
        newEntropy = 0.0
        for key in keys:
            subDataSet = split(dataSet, col, key)
            prob = len(subDataSet) / float(len(dataSet))
            newEntropy += prob * entropy(subDataSet,target)
        infoGain = baseEntropy - newEntropy
        # print("第",i,"个信息增益：",infoGain)
        if (infoGain > bestInfoGain):
            bestInfoGain = infoGain
            best_col = col
    # print("最佳特征：",bestFeature)
    return best_col



def chooseAgeBoundary(dataSet,col,target):
    """
        该方法，仅仅是用于对年龄进行划分
    :param dataSet: pandas 的DataFrame
    :param col:数据集的col(属性),此处其实就是‘age’
    :param target:划分目标属性col
    :return: 数据集在col(属性下)，最好的二划分
    """
    baseEntropy = entropy(dataSet,target)
    bestInfoGain = 0.0
    best_value = -1
    col_values = (dataSet.sort_values(by=col)[col]).to_numpy()
    for i in range(1,len(col_values)):
        if col_values[i-1] != col_values[i]:
            v = (col_values[i-1] + col_values[i])/2
            subData_l,subData_r= split_value(dataSet,col,v)
            prob_l,prob_r = len(subData_l) / float(len(dataSet)),len(subData_r) / float(len(dataSet))
            newEntropy = prob_l * entropy(subData_l,target) + prob_r * entropy(subData_r,target)
            infoGain = baseEntropy - newEntropy
            # print("第",i,"个信息增益：",infoGain)
            if (infoGain > bestInfoGain):
                bestInfoGain = infoGain
                best_value = v
    # print("最佳特征：",bestFeature)
    return best_value

def getBoundary(dataSet, col, target, boundary, max_size):
    if len(boundary) > max_size:
        return
    best_val = chooseAgeBoundary(dataSet,col,target)
    boundary.append(best_val)
    subData_l, subData_r = split_value(dataSet, col, best_val)
    getBoundary(subData_l, col, target, boundary, max_size - 1)
    getBoundary(subData_r, col, target, boundary, max_size - 1)

def createTree(dataset,cols,target):
    lables = dataset[target].value_counts()
    #或者计算target属性下的标签种类，如果只有1个，说明是同一标签无需再分，则直接返回
    if len(lables.keys()) == 1:
        return lables.keys()[0]
    # 如果只有属性(col),但是类别标签又多个,选取类别最多的作为返回值
    if  len(cols) == 1:
        return dataset[cols[0]].value_counts().keys()[0]
    best_col = chooseBestFeature(dataset,cols,target)  # 选取信息增益最大的特征作为下一次分类的依据
    #如果无法做出更好的划分，即best_col == -1,那么就将将lable中最多的作为
    if best_col == -1:
        return lables.keys()[0]
    mytree = {best_col: {}}  # 创建tree字典，紧跟现阶段最优特征，下一个特征位于第二个大括号内，循环递归
    cols = cols.drop(best_col)
    val_counts = dataset[best_col].value_counts()
    keys = val_counts.keys()#best_col下的标签
    for key in keys:
        mytree[best_col][key] = createTree(split(dataset, best_col, key),cols, target)  # 循环递归生成树
    return mytree


def check_data(data1, data2):
    """检测两类数据的标签的种类是否相同"""
    assert isinstance(data1, pd.DataFrame) and isinstance(data2,pd.DataFrame), \
        'data1,data2 must belong to the type of pandas.DataFrame'

    if len(data1.columns.values) != len(data2.columns.values):
        return False
    if not (data1.columns.values == data2.columns.values).all():
        return False
    columns = data1.columns.values
    flag = True
    for col in columns:
        flag = flag and (len(data1[col]) == len(data2[col]))
    return flag


def prepare_train_test(data,ratio):
    #ratio 训练集占比
    num_examples = len(data)
    train_size = int(ratio*num_examples)
    max_time = 10
    for i in range(max_time):
        train_data = data.sample(frac=1)[:train_size]
        if check_data(data,train_data) :
            break
    test_data = data[train_size:]
    return train_data,test_data

def predict(tree, example):
    assert isinstance(tree,dict) ,'the type of "tree" must be a dictionary'
    subtree = tree
    # 字典构成的决策树中，叶子节点都是数字0/1，(live/die)
    # 并且，数值类型为np.int64
    while (not isinstance(subtree,np.int64)):
        keys = subtree.keys()
        key = [k for k in keys][0]
        subtree = subtree[key]
        value = example[key]
        subtree = subtree[value]
    return subtree

def evaluate(tree,test_set,target):
    nums_examples = len(test_set)
    predict_array = []
    for i in range(len(test_set)):
        predict_array.append(predict(tree,test_set.iloc[i]))
    predict_array = np.array(predict_array)
    real_array = test_set[target].to_numpy()

    #1.准确率accuracy： 被正确分类的样本数/样本总数
    accuracy = (predict_array == real_array).sum()/float(nums_examples)

    #2.精确率precision： 被正确分类的正例样本数/总的正例样本数
    precision = (predict_array[real_array == 1]).sum()/float(predict_array.sum())

    #3.召回率recall： 被正确分类的正例样本数/所有被正确分类的样本数
    recall = (predict_array[real_array == 1]).sum()/float(real_array.sum())

    print('accuracy:',accuracy)
    print('precision:',precision)
    print('recall:',recall)

def cope_data(filename):
    #file_name = 'C:/Users/Mr.Li/Desktop/LAB1/dataset.csv'
    dF = pd.read_csv(file_name, header=0)
    dF.loc[dF['embarked'] == 'female', 'sex'] = 'female'
    dF.loc[dF['embarked'] == 'female', 'embarked'] = 'Southampton'
    dF.loc[dF['sex'] == 'male"', 'sex'] = 'male'
    average_age = dF["age"].mean()
    new_age = dF['age'].copy()
    new_age[dF.age.isnull()] = average_age
    dF["age"] = new_age
    dF.drop(['row.names', 'name'], axis=1, inplace=True)
    child = dF['age'] <= 12
    teenager = (dF['age'] <= 18) & (dF['age'] > 12)
    adult = (dF['age'] <= 65) & (dF['age'] > 18)
    senior = (dF['age'] <= 100) & (dF['age'] > 65)

    dF.loc[child, 'age'] = 'child'
    dF.loc[teenager, 'age'] = 'teenager'
    dF.loc[adult, 'age'] = 'adult'
    dF.loc[senior, 'age'] = 'senior'
    return dF

if __name__=='__main__':
    file_name = 'C:/Users/Mr.Li/Desktop/LAB1/dataset.csv'
    dF = cope_data(file_name)



    #计算age的可能的划分
    # boundary = []
    # max_size = 3
    # getBoundary(dF,'age','survived',boundary,max_size)
    # print(boundary)

    #划分训练集train_set 、 test_set (ratio = 0.7)
    train_set,test_set= prepare_train_test(dF,0.7)
    tree = createTree(train_set, train_set.columns, 'survived')
    print(tree)
    Tree_visual.createTree(tree,'决策树')
    evaluate(tree,test_set,'survived')